#!/bin/bash

if [ 12 -lt 21 ] && [ -n "Neko" ]; then
    echo "テスト成功"
else
    echo "テスト失敗"
fi